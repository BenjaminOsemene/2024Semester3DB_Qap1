INSERT INTO patients (first_name, last_name, date_of_birth, gender, email, phone_number, address, city, state, zip_code, medical_history, allergies, primary_physician)
VALUES
    ('John', 'Doe', '1990-05-15', 'M', 'john.doe@email.com', '555-1234', '123 Main St', 'Cityville', 'CA', '12345', 'Diabetes', 'Penicillin', 'Dr. Smith'),
    ('Jane', 'Doe', '1985-09-22', 'F', 'jane.doe@email.com', '555-5678', '456 Oak Ave', 'Townville', 'NY', '67890', 'Asthma', 'Shellfish', 'Dr. Johnson'),
    ('Bob', 'Smith', '1975-03-10', 'M', 'bob.smith@email.com', '555-9012', '789 Elm Rd', 'Cityville', 'CA', '12345', 'High Blood Pressure', 'None', 'Dr. Williams'),
    ('Alice', 'Johnson', '1992-11-28', 'F', 'alice.johnson@email.com', '555-3456', '246 Pine St', 'Townville', 'NY', '67890', 'None', 'Peanuts', 'Dr. Brown');

INSERT INTO appointments (patient_id, appointment_date, appointment_time, reason, physician)
VALUES
    (1, '2024-05-10', '10:00:00', 'Routine Checkup', 'Dr. Smith'),
    (2, '2024-05-12', '14:30:00', 'Asthma Follow-up', 'Dr. Johnson'),
    (3, '2024-05-15', '09:00:00', 'Blood Pressure Monitoring', 'Dr. Williams'),
    (4, '2024-05-18', '11:15:00', 'Allergy Testing', 'Dr. Brown'),
    (1, '2024-05-20', '16:00:00', 'Diabetes Management', 'Dr. Smith');
	
	SELECT
    first_name,
    last_name,
    date_of_birth,
    primary_physician
FROM
    patients;
	
	SELECT
    first_name,
    last_name,
    date_of_birth,
    primary_physician
FROM
    patients
WHERE
    date_of_birth >= '1990-01-01';
	
	SELECT
    gender,
    COUNT(*) AS patient_count
FROM
    patients
GROUP BY
    gender;
	
	SELECT
    first_name,
    last_name,
    date_of_birth,
    primary_physician
FROM
    patients
ORDER BY
    last_name,
    first_name;