INSERT INTO address (address, district, city_id, postal_code, phone)
VALUES ('456 Oak St', 'Newtown', 5, '67890', '555-9876')
RETURNING address_id;


UPDATE customer
SET address_id = 101
WHERE last_name = 'Doe';