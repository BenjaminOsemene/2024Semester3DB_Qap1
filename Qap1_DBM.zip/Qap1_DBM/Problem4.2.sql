CREATE TABLE Enrollments (
    EnrollmentID SERIAL PRIMARY KEY,
    StudentID INT NOT NULL,
    EnrollmentDate DATE NOT NULL,
    TotalFee DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (StudentID) REFERENCES Students(StudentID)
);