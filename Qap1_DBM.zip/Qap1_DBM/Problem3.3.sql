SELECT COUNT(*) FROM customer WHERE address_id = 100;

UPDATE customer
SET address_id = 101
WHERE address_id = 100;


DELETE FROM address
WHERE address_id = 100;