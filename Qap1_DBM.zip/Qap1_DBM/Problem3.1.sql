SELECT city_id FROM city WHERE city = 'Cityville';

INSERT INTO address (address, district, city_id, postal_code, phone)
VALUES ('123 Main St', 'Cityville', 3, '12345', '555-0123')
RETURNING address_id;

INSERT INTO customer (store_id, first_name, last_name, email, address_id)
VALUES
  (1, 'John', 'Doe', 'john.doe@example.com', 100),
  (1, 'Jane', 'Doe', 'jane.doe@example.com', 100),
  (1, 'Bobby', 'Doe', 'bobby.doe@example.com', 100),
  (1, 'Samantha', 'Doe', 'samantha.doe@example.com', 100);